//
//  Aircraft.cpp
//  test
//
//  Created by Naim Sakaamini on 2018-10-17.
//  Copyright © 2018 Naim Sakaamini. All rights reserved.
//

#include "Aircraft.h"


Aircraft::Aircraft(unsigned int SeatCount)
{
    Manifest = new Passenger[NumOfPassengers];

}


Aircraft::Aircraft(Aircraft& src) : NumOfPassengers(src.NumOfPassengers)
{
    for(int i = 0; i < NumOfPassengers; i++)
    {
        this->Manifest[i] = src.Manifest[i];
    }
}


Aircraft& Aircraft::operator=(Aircraft& src)
{
    if (this != &src)
    {
        delete[] this->Manifest;
        this->NumOfPassengers = src.NumOfPassengers;
        this->Manifest = new Passenger[NumOfPassengers];
        for(int i = 0; i < NumOfPassengers; i++)
        {
            this->Manifest[i] = src.Manifest[i];
        }
        return *this;
    }
}



//Capability to add and remove passengers
Aircraft& Aircraft::operator+=(Passenger& newPassenger)
{
    if(newPassenger.SeatNumber == 0)
        throw "no seat assigned"
        else if (NumOfSeats == NumOfPassengers)
                 throw "plane is full"
            else if(newPassenger.SeatNumber == Passenger& seatnum)
                throw "double booking"
    Manifest[NumOfPassengers] = newPassenger;
    NumOfPassengers++;
}//Adds a passenger to the manifest



Aircraft& Aircraft::operator-=(std::string name)
{
    Passenger passenger(name);
    Manifest[NumOfPassengers] = std::move(name);
}
//Removes a passenger from the manifest

unsigned int Aircraft::getPassengerCount()
{
    return NumOfPassengers;
}//Returns the number of passengers on the plane


void Aircraft::display(std::ostream& os)
{
    for (int i = 0; i < NumOfSeats; i++)
    {
        if(Manifest[i].GetSeat() == -1)
        {
            os << "seat " << Manifest[i].GetSeat() <<"is empty" << std::endl;
        }
        else
        {
        os << manifest[i].getname() <<": "<< Manifest[i].GetSeat() << std::endl;
        }
        
        
    }
}
