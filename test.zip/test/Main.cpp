#include <iostream>
#include <fstream>
#include "Aircraft.h"
#include "Passenger.h"

int main(int argc, char* argv[])
{
	std::ofstream* ofs = nullptr;
	if (argc == 2)
		ofs = new std::ofstream(argv[1]);

	Passenger Elliott("Elliott");
	Passenger John("John");
	Passenger Jane("Jane");

	Aircraft AC150(3);
	Elliott.AssignSeat(0);
	John.AssignSeat(1);

	try {
		AC150 += Elliott;
		AC150 += John;
		AC150 += Jane;
	}
	catch (const char* error)
	{
		if (argc == 2)
			*ofs << error << std::endl;
		else
			std::cout << error << std::endl;
	};

	if (argc == 2)
		AC150.display(*ofs);
	else
		AC150.display(std::cout);

	Jane.AssignSeat(1);

	try {
		AC150 += Jane;
	}
	catch (const char* error)
	{
		if (argc == 2)
			*ofs << error << std::endl;
		else
			std::cout << error << std::endl;
	}

	Jane.AssignSeat(2);
	AC150 += Jane;

	if (argc == 2)
		AC150.display(*ofs);
	else
		AC150.display(std::cout);
	
	Passenger Mike("Mike");
	Mike.AssignSeat(3);

	try {
		AC150 += Mike;
	}
	catch(const char* error){

		if (argc == 2)
			*ofs << error << std::endl;
		else
			std::cout << error << std::endl;
	}

	Aircraft Cactus1459(10);
	if (argc == 2)
	{
		*ofs << "Number of Passengers on AC150 = " << AC150.getPassengerCount() << std::endl;
		Cactus1459 = AC150;

		Cactus1459 -= John.getName();
		*ofs<< "Number of Passengers on Cactus1459 = " << Cactus1459.getPassengerCount() << std::endl;
		Cactus1459.display(*ofs);
	}
	else
	{
		std::cout << "Number of Passengers on AC150 = " << AC150.getPassengerCount() << std::endl;
		Cactus1459 = AC150;

		Cactus1459 -= John.getName();
		std::cout << "Number of Passengers on Cactus1459 = " << Cactus1459.getPassengerCount() << std::endl;
		Cactus1459.display(std::cout);

		AC150.display(std::cout);
	}

	unsigned int WaitKey;
	std::cout << "Press any key to continue";
	std::cin >> WaitKey;

	return 1;
}