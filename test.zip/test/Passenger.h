#pragma once
#include <iostream>

class Passenger
{
	std::string Name;
    int SeatNumber;

public:
	Passenger();
	Passenger(std::string);

	Passenger(Passenger&) = delete;
	Passenger& operator=(Passenger&) = delete;

	Passenger(Passenger&&);
	Passenger& operator=(Passenger&&);

	void AssignSeat(unsigned int);
	unsigned int GetSeat();
	std::string& getName();
};
