#include "Passenger.h"

Passenger::Passenger() : Name(""), SeatNumber(-1) {};
Passenger::Passenger(std::string src) : Name(src), SeatNumber(-1) {};

Passenger::Passenger(Passenger&& src) { *this = std::move(src); };
Passenger& Passenger::operator=(Passenger&& src)
{
	if (this != &src)
	{
		Name = src.Name;
		SeatNumber = src.SeatNumber;
	}
	return *this;
}

void Passenger::AssignSeat(unsigned int value) { SeatNumber = value; };
unsigned int Passenger::GetSeat() { return SeatNumber; };
std::string& Passenger::getName() { return Name; };
