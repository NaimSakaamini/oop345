#pragma once
#include <iostream>
#include "Passenger.h"

class Aircraft
{
	Passenger* Manifest;
	unsigned int NumOfSeats;
	unsigned int NumOfPassengers;

public:
	Aircraft(unsigned int);

	Aircraft(Aircraft&);
	Aircraft& operator=(Aircraft&);

	Aircraft(Aircraft&&) = delete;
	Aircraft& operator=(Aircraft&&) = delete;

	//Capability to add and remove passengers
	Aircraft& operator+=(Passenger&);			//Adds a passenger to the manifest
	Aircraft& operator-=(std::string&);			//Removes a passenger from the manifest

	unsigned int getPassengerCount();			//Returns the number of passengers on the plane
	void display(std::ostream&);
};